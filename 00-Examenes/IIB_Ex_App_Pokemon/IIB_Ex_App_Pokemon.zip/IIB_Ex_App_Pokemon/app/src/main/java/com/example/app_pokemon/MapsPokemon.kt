package com.example.app_pokemon

import android.content.pm.PackageManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.util.Log
import com.beust.klaxon.Klaxon
import com.github.kittinunf.fuel.httpGet
import com.github.kittinunf.result.Result

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapsPokemon : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var tienePermisosLocalizacion = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //solicitarPermisosLocalizacion()
        setContentView(R.layout.activity_maps_pokemon)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        val foch = LatLng(-0.209369, -78.489530)
        val titulo = "Plaza Foch"
        val zoom = 17f
        anadirMarcador(foch,titulo)
        moverCamaraConZom(foch, zoom)
    }

    // Crear marcador
    private fun anadirMarcador(latLng: LatLng, title:String){
        mMap.addMarker(
            MarkerOptions()
                .position(latLng)
                .title(title)
        )
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera
        val sydney = LatLng(-34.0, 151.0)
        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))
    }

    private fun moverCamaraConZom(latLng: LatLng, zoom:Float = 10f){
        mMap.moveCamera(CameraUpdateFactory
            .newLatLngZoom(latLng,zoom)
        )
    }

    private fun cargarCoordenadasPokemones(): ArrayList<ClasePokemones>{
        val url = ClaseServidorBackend.getURL("pokemon")
        Log.i("http", "Mi URL: $url")
        val pokemones = arrayListOf<ClasePokemones>()
        url.httpGet().responseString {_, _, result ->
            when (result) {
                is Result.Failure -> {
                    val ex = result.getException()
                    Log.i("http", "Error get pokemones: ${ex.message}")
                }
                is Result.Success -> {
                    val data = result.get()
                    Log.i("http", data)
                    val datosParseados = Klaxon().parseArray<ClasePokemones>(data)
                    datosParseados!!.forEach{
                        pokemones.add(it)
                        Log.i("http", "${it.id} - ${it.nombrePokemon}")
                    }
                }
            }
        }
        return pokemones
    }

    private fun establecerConfiguracionMaps(mapa: GoogleMap){

        val contexto = this.applicationContext // Guardando el contexto de  la actividad
        // Para que no de el error en el caso de no tener permisos.
        with(mapa){

            // Copiando aqui:
            val permisoFineLocation = ContextCompat
                .checkSelfPermission(
                    contexto,
                    android.Manifest.permission.ACCESS_FINE_LOCATION
                )
            val tienePermiso = permisoFineLocation == PackageManager.PERMISSION_GRANTED
            // Siempre hay que revisar que si realmenet tenemos permisos para acceder a la localización.
            if(tienePermiso){
                mapa.isMyLocationEnabled = true
            }
            this.uiSettings.isZoomControlsEnabled = true
            uiSettings.isMyLocationButtonEnabled= true        }
    }

    private fun solicitarPermisosLocalizacion(){
        val permisoFineLocation = ContextCompat
            .checkSelfPermission(
                this.applicationContext,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )
        val tienePermiso = permisoFineLocation == PackageManager.PERMISSION_GRANTED

        if(tienePermiso){
            Log.i("mapa","Tiene permisos de FINE_LOCATION")
            this.tienePermisosLocalizacion = true
        }else{
            ActivityCompat.requestPermissions(
                this,
                arrayOf( // Arreglo de permisos
                    android.Manifest.permission.ACCESS_FINE_LOCATION
                ),
                1 // Código que vamps a esperar
            )
        }

    }
}
