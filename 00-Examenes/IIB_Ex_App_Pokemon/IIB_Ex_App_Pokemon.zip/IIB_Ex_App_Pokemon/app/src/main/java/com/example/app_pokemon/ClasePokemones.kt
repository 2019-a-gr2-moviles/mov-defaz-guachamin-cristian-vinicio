package com.example.app_pokemon

class ClasePokemones(
    var id: Int,
    var nombrePokemon: String,
    var poderUno: String,
    var poderDos: String,
    var fechaCaptura: String,
    var nivel: Int,
    var latitud: String,
    var longitud: String

)